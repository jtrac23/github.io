[Readme]

NAS ZTUDIO

� 20 Icons
� Ready to Use
� High quality and resolution
� SVG File
� PNG File
� Ai File

If you need specific icons in future updates please tell us via email or messages on CreativeMarket.
Please, report us if you found any bug or have suggestions to: imnasztu@gmail.com

Follow us on Twitter: https://twitter.com/nasztu and 
like our Facebook page: https://www.facebook.com/nas.ztu

Don�t forget to check my collections for more items
https://creativemarket.com/nasztu

My Site : http://nasztu.com/