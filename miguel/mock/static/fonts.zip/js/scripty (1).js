//Takes information from the register form and pushes it to the PostRegistration function in Controller
$(document).ready(function(){
    console.log("loaded");
    $.material.init();

    $(document).on("submit", "#register-form", function(e){
        e.preventDefault();
        console.log("Form Submitted");
        var form = $('#register-form').serialize();
        $.ajax({
            url: '/postregistration',
            type: 'POST',
            data: form,
            success: function(response){
                console.log(response);
                alert("Thanks! Please Login.");
                window.location.href= "/";
            }
        });
    });
//Takes data from the login form and pushes it to the Login function in Controller
    $(document).on("submit", "#login-form", function(e){
        e.preventDefault();

        var form = $(this).serialize();
        $.ajax({
            url: '/check-login',
            type: 'POST',
            data: form,
            success: function(response){
                if(response == "error"){
                    alert("Could not log in");
                }else{
                    console.log("Logged in as: ", response);
                    window.location.href = "/";
                }
            }
        });
    });
//Activates the logout function in Controller and redirects to the login page
    $(document).on('click', '#logout-link', function(e){
        e.preventDefault();
        $.ajax({
            url: '/logout',
            type: 'GET',
            success: function(res){
                if(res == "Success"){
                    window.location.href = '/login';
                } else {
                    alert("Something went horribly wrong");
                }
            }
        });
    });
    //Takes data from the "Chrip"/post-form and pushes it into MongoDB
    $(document).on('submit', '#post-form', function(e){
        console.log("Content to passed to scripty");
        e.preventDefault();
        var form = $(this).serialize();
        $.ajax({
            url: '/post-activity',
            type: 'POST',
            data: form,
            success: function(res){
                console.log(res);
                window.location.href="/";
            }
        });
    });
});


